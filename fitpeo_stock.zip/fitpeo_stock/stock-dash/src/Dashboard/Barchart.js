import React, { PureComponent, useState } from "react";
import {
  BarChart,
  Bar,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

const chartData = [
  {
    name: "jan",
    uv: 6000,
    pv: 2400,
    amt: 1000,
  },
  {
    name: "feb",
    uv: 3000,
    pv: 1398,
    amt: 600,
  },
  {
    name: "mar",
    uv: 5000,
    pv: 9800,
    amt: 1200,
  },
  {
    name: "april",
    uv: 4500,
    pv: 3908,
    amt: 800,
  },
  {
    name: "may",
    uv: 6555,
    pv: 4800,
    amt: 1400,
  },
  {
    name: "jun",
    uv: 4000,
    pv: 3800,
    amt: 1450,
  },
  {
    name: "jul",
    uv: 3000,
    pv: 4900,
    amt: 1200,
  },
  {
    name: "aug",
    uv: 8999,
    pv: 5000,
    amt: 2100,
  },
  {
    name: "sep",
    uv: 4888,
    pv: 3300,
    amt: 1750,
  },
  {
    name: "oct",
    uv: 6000,
    pv: 1100,
    amt: 1220,
  },
  {
    name: "nov",
    uv: 7490,
    pv: 4300,
    amt: 900,
  },
  {
    name: "dec",
    uv: 2490,
    pv: 1300,
    amt: 2500,
  },
];

function Barchart() {
  const [activeIndex, setActiveIndex] = useState(); // Removed the unnecessary 'setData' state

  const handleClick = (index) => {
    // Updated the 'handleClick' function
    setActiveIndex(index);
  };

  return (
    <ResponsiveContainer width="100%" height={180}>
      <BarChart width={150} height={40} data={chartData}>
        <XAxis dataKey="name" />
        <Bar dataKey="uv" onClick={(_, index) => handleClick(index)}>
          {" "}
          {/* Pass index to handleClick */}
          {chartData.map((entry, index) => (
            <Cell
              cursor="pointer"
              fill={
                entry.name === "aug"
                  ? "#4B0082"
                  : index === activeIndex
                  ? "#4B0082"
                  : "#C0C0C0"
              }
              key={`cell-${index}`}
            />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

export default Barchart;
