import React from "react";
import { Tabledata } from "./Tabledata.js";

const Table = () => {
  return (
    <div className="Table-content">
      <div className="Table-container">
        <div id="table-head">
          <h1>Product Sell</h1>
        </div>
        <div id="tablehead-2">
          <input type="text" placeholder="Search" />
        </div>
        <div id="tablehead-3">
          <table>
            <thead>
              <tr>
                <th>Product Name</th>
                <th>Stock</th>
                <th>Price</th>
                <th>Total Sales</th>
              </tr>
            </thead>
            <tbody>
              {Tabledata.map((val) => {
                return (
                  <tr key={val.id}>
                    <td>
                      <img
                        src={val.productimage}
                        alt={val.productname}
                        style={{ maxHeight: "35px", maxWidth: "60px" }}
                      />
                      &nbsp;&nbsp;
                      {val.productname}
                    </td>
                    <td>{val.stock}</td>
                    <td>{val.price}</td>
                    <td>{val.Totalsales}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Table;
