import React from "react";
import Barchart from "./Barchart";
import Datapie from "./Datapie";

function Piecharts() {
  return (
    <div className="piechart-container">
      <div className="pieconteiner">
        <div id="pie-content1">
          <div id="pie-chart">
            <h1>Overview</h1>
            <p>Monthly Earning</p>
            <Barchart />
          </div>
        </div>
        <div id="pie-content2">
          <div id="pie-chart">
            <Datapie />
          </div>
        </div>
      </div>
    </div>
  );
}

export default Piecharts;
