export const Tabledata = [
  {
    id: 0,
    productname: "Abstract 3D",
    productimage:
      "https://images.pexels.com/photos/5011647/pexels-photo-5011647.jpeg?cs=srgb&dl=pexels-rostislav-uzunov-5011647.jpg&fm=jpg",
    stock: "32 in stock.",
    price: "$104",
    Totalsales: 24,
  },
  {
    id: 1,
    productname: "Sarphens Illustration",
    productimage:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzYMlR9XG5dJCnHCGnDfg6-_Pee2PHpoD6LA&usqp=CAU",
    stock: "32 in stock.",
    price: "$108",
    Totalsales: 30,
  },
];
