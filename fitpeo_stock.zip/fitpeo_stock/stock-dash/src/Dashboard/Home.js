import React from "react";
import SearchIcon from "@mui/icons-material/Search";
import Dashboard from "./Dashboard.js";

function Home() {
  return (
    <>
      <div className="dashboard">
        <div className="header">
          <div className="header-left">
            <h1>Hello User,</h1>
          </div>
          <div className="header-right">
            <input type="text" placeholder="Search" />
          </div>
        </div>
        <Dashboard />
      </div>
    </>
  );
}

export default Home;
