import logo from "./logo.svg";
import "./App.css";
import Sidebar from "./Dashboard/Sidebar.js";
import Home from "./Dashboard/Home.js";

function App() {
  return (
    <div className="grid-container">
      <Sidebar />
      <Home />
    </div>
  );
}

export default App;
