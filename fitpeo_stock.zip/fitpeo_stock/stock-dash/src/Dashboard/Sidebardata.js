import React from "react";
import DashboardIcon from "@mui/icons-material/Dashboard";
import ViewInArIcon from "@mui/icons-material/ViewInAr";
import GroupIcon from "@mui/icons-material/Group";
import PaidIcon from "@mui/icons-material/Paid";

export const Sidebardata = [
  {
    title: "Dashboard",
    icon: <DashboardIcon />,
    link: "/home",
  },
  {
    title: "Products",
    icon: <ViewInArIcon />,
    link: "/products",
  },
  {
    title: "Customers",
    icon: <GroupIcon />,
    link: "/customers",
  },
  {
    title: "Income",
    icon: <PaidIcon />,
    link: "/income",
  },
  {
    title: "Promote",
    icon: <DashboardIcon />,
    link: "/promote",
  },
  {
    title: "Help",
    icon: <DashboardIcon />,
    link: "/help",
  },
];
