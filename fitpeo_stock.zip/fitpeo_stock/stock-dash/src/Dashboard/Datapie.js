import React from "react";
import { PieChart, Pie, Cell, ResponsiveContainer } from "recharts";
const data = [
  { name: "Group A", value: 20 },
  { name: "Group B", value: 20 },
  { name: "Group C", value: 25 },
];
const COLORS = ["#FF00FF", "#4B0082", "#C0C0C0"];

function Datapie() {
  const totalValue = data.reduce((acc, entry) => acc + entry.value, 0);

  return (
    <div>
      <h1>Customers</h1>
      <p>Customers that buy projects.</p>
      <ResponsiveContainer width="100%" height={175}>
        <PieChart>
          <text
            x="50%"
            y="50%"
            textAnchor="middle"
            dominantBaseline="middle"
            fontSize={20}
            fill="#333"
          >
            {totalValue}
          </text>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={30}
            outerRadius={80}
            fill="#8884d8"
            paddingAngle={5}
            dataKey="value"
          >
            {data.map((entry, index) => (
              <Cell
                key={`cell-${index}`}
                fill={COLORS[index % COLORS.length]}
              />
            ))}
          </Pie>
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}

export default Datapie;
