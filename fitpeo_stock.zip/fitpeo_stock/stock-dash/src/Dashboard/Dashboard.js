import React from "react";
import MonetizationOnIcon from "@mui/icons-material/MonetizationOn";
import AssignmentIcon from "@mui/icons-material/Assignment";
import AccountBalanceWalletIcon from "@mui/icons-material/AccountBalanceWallet";
import ShoppingBagIcon from "@mui/icons-material/ShoppingBag";
import Piecharts from "./Piecharts";
import Table from "./Table.js";

function Dashboard() {
  return (
    <div className="body">
      <div className="body-container">
        <div className="cards-container">
          <div className="image">
            <MonetizationOnIcon id="card-image" />
          </div>
          <div>
            <p>Earning</p>
            <h1>$134K</h1>
            <p>
              <span>37.84&#8593;</span>this month
            </p>
          </div>
        </div>
        <div className="cards-container">
          <div className="image">
            <AssignmentIcon id="card-image2" />
          </div>
          <div>
            <p>Order</p>
            <h1>$2.4k</h1>
            <p>
              <span>2&#8593;</span>this month
            </p>
          </div>
        </div>

        <div className="cards-container">
          <div className="image">
            <AccountBalanceWalletIcon id="card-image3" />
          </div>
          <div>
            <p>Balance</p>
            <h1>$2.4k</h1>
            <p>
              <span>2&#8593;</span>this month
            </p>
          </div>
        </div>

        <div className="cards-container">
          <div className="image">
            <ShoppingBagIcon id="card-image4" />
          </div>
          <div>
            <p>Local Balance</p>
            <h1>$89k</h1>
            <p>
              <span>11&#8593;</span>this month
            </p>
          </div>
        </div>
      </div>
      <Piecharts />
      <Table />
    </div>
  );
}

export default Dashboard;
